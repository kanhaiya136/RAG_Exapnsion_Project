# RAG_Expantion_sknInvotech
 To expand the capabilities of the Retrieval-Augmented Generation  (RAG) system to process and understand content in multiple languages from videos and audio files. 
